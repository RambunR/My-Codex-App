import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';

const [command,...args]=process.argv.slice(2);
if(!command){console.error('Usage: node verify-mcp.mjs <server-command> [server arguments...]');process.exit(2);}
const child=spawn(command,args,{stdio:['pipe','pipe','pipe'],env:process.env});
const pending=new Map();let nextId=0;let buffer='';let stderr='';let initialized=false;let verified=false;
const redact=value=>String(value).replace(/https?:\/\/[^\s/@]+:[^\s/@]+@/g,'https://[redacted]@').replace(/\b(?:sk|rk)_(?:test|live)_[A-Za-z0-9]+\b/g,'[redacted]').replace(/\b(?:sk-proj-|sk-ant-|ghp_|github_pat_)[A-Za-z0-9_-]+\b/g,'[redacted]');
function failPending(error){for(const item of pending.values()){clearTimeout(item.timer);item.reject(error);}pending.clear();}
child.on('error',error=>failPending(error));
child.on('exit',code=>failPending(new Error('MCP process exited with code '+code)));
child.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString()).slice(-5000);});
child.stdout.on('data',chunk=>{
  buffer+=chunk.toString();
  for(let index;(index=buffer.indexOf('\n'))>=0;){
    const line=buffer.slice(0,index);buffer=buffer.slice(index+1);if(!line.trim())continue;
    let message;try{message=JSON.parse(line);}catch{continue;}
    if(!pending.has(message.id))continue;
    const item=pending.get(message.id);pending.delete(message.id);clearTimeout(item.timer);
    if(message.error)item.reject(new Error('MCP protocol error: '+message.error.message));else item.resolve(message.result);
  }
});
function request(method,params={}){
  const id=++nextId;
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(new Error('Timed out waiting for '+method));},30000);
    pending.set(id,{resolve,reject,timer});
    child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n',error=>{if(error){clearTimeout(timer);pending.delete(id);reject(error);}});
  });
}
async function tool(name,arguments_={}){
  const result=await request('tools/call',{name,arguments:arguments_});
  if(result?.isError)throw new Error(name+' failed: '+redact((result.content||[]).filter(item=>item.type==='text').map(item=>item.text).join('\n')).slice(0,1200));
  return result;
}
function text(result){return(result?.content||[]).filter(item=>item.type==='text').map(item=>item.text).join('\n');}
try{
  const hello=await request('initialize',{protocolVersion:'2025-03-26',capabilities:{},clientInfo:{name:'aidramio-browser-setup-check',version:'1.0.0'}});
  initialized=true;child.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized',params:{}})+'\n');
  const listed=await request('tools/list');const names=(listed.tools||[]).map(item=>item.name);
  for(const name of ['browser_navigate','browser_snapshot','browser_click','browser_evaluate','browser_close'])if(!names.includes(name))throw new Error('Required browser tool missing: '+name);
  await tool('browser_navigate',{url:'about:blank'});
  await tool('browser_evaluate',{function:"() => { document.title = 'AIDramio MCP verification'; document.body.innerHTML = ''; const b = document.createElement('button'); b.id = 'aidramio-mcp-check'; b.textContent = 'Verify MCP'; b.onclick = () => { b.textContent = 'Clicked'; }; document.body.appendChild(b); return document.title; }"});
  const snapshot=text(await tool('browser_snapshot'));
  const line=snapshot.split('\n').find(value=>value.includes('button')&&value.includes('Verify MCP'));
  const ref=line?.match(/\[ref=([^\]]+)\]/)?.[1];if(!ref)throw new Error('Browser inspection did not find the test button.');
  const clickSchema=listed.tools.find(item=>item.name==='browser_click').inputSchema;
  const targetArgument=clickSchema.properties?.target?{target:ref}:{ref};
  await tool('browser_click',{element:'Verify MCP test button',...targetArgument});
  const after=text(await tool('browser_evaluate',{function:"() => document.getElementById('aidramio-mcp-check').textContent"}));
  if(!after.includes('Clicked'))throw new Error('Browser click verification failed.');
  verified=true;
  const summary={ok:true,server:hello.serverInfo,protocol:hello.protocolVersion,toolCount:names.length,navigate:true,inspect:true,click:true,scope:'This process and its separate test browser; desktop attachment is checked after restart.'};
  console.log(JSON.stringify(summary,null,2));
  if(process.env.AIDRAMIO_MCP_REPORT)await fs.writeFile(process.env.AIDRAMIO_MCP_REPORT,JSON.stringify(summary,null,2)+'\n',{mode:0o600});
}catch(error){
  console.error(redact(error.message));if(stderr.trim())console.error(redact(stderr).slice(-1800));process.exitCode=1;
}finally{
  if(initialized)await tool('browser_close').catch(()=>{});
  failPending(new Error('Setup check finished.'));
  child.stdin.end();
  if(child.exitCode===null){await new Promise(resolve=>{const timer=setTimeout(resolve,1000);child.once('exit',()=>{clearTimeout(timer);resolve();});});if(child.exitCode===null)child.kill('SIGTERM');}
  if(!verified)process.exitCode=1;
}
