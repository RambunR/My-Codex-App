# AIDramio browser tool setup for Mac

1. Download **Setup-AIDramio-Browser.command** and run it on your Mac (or unzip the bundle and run that file). It is self-contained. Double-click it, or run `bash` followed by the file path in Terminal. If macOS blocks opening it, use **Control-click → Open**; keep macOS security settings enabled.
2. When it reports success, open the desktop app’s **Settings → MCP servers**, select **playwright**, then **Restart**. Continue in a chat using **this Mac/local computer**. In supported local clients, `/mcp` shows connected servers.
3. Ask the local agent: **“Use Playwright to open Apple Developer and inspect AIDramio’s Sign in with Apple configuration.”** A separate browser opens. Sign in to Apple yourself in that window when needed.

The installer sets up pinned Microsoft Playwright MCP **0.0.83**, downloads its matching Chromium, verifies real browser navigation/inspection/clicks, and adds or updates only the **playwright** MCP entry. It uses an existing Node.js 18+ with npm when available, otherwise downloads a private, checksum-verified official Node.js **24.22.2** runtime. That fallback requires macOS 13.5 or newer. A pinned official Codex CLI **0.165.0** is used only if an existing compatible CLI is unavailable.

Everything is installed under `~/Library/Application Support/AIDramio/BrowserMCP/`. No administrator password or global npm installation is used. Existing Codex configuration is backed up privately before registration; other MCP entries are preserved. The launcher uses absolute executable paths to avoid desktop PATH problems.

This controls a **separate local browser**, with a private persistent profile. It does **not** attach ChatGPT’s built-in side tab, automatically connect this cloud chat to your Mac, or fix Apple’s `invalid_client` registration error by itself. Installation verification covers the local tools; successful Apple sign-in must be checked afterward. Keep passwords, Apple verification codes, private keys and browser-profile files out of chat.

If setup fails, send the final error message or a screenshot of the error. Keep the existing configuration and its private backups out of screenshots. You can rerun the same installer after correcting the reported issue.

Official references: [Playwright MCP](https://github.com/microsoft/playwright-mcp) · [Codex MCP configuration](https://developers.openai.com/codex/mcp/).

The included `verification-cloud.json` records a successful test in the cloud workspace. Your Mac runs its own verification during setup and writes a separate private report. The Mac installer was reviewed and syntax-checked here; executing its macOS steps requires your Mac.
